package com.mylauncher.tv

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.tv.TvContract
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

// ---- ВХОДЫ (взяты из dumpsys tv_input вашего телевизора) ----
private const val HDMI1 = "com.mediatek.tvinput/.hdmi.HDMIInputService/HW4"
private const val HDMI2 = "com.mediatek.tvinput/.hdmi.HDMIInputService/HW5"
private const val HDMI3 = "com.mediatek.tvinput/.hdmi.HDMIInputService/HW6"
private const val AV = "com.mediatek.tvinput/.composite.CompositeInputService/HW1"

// ---- Палитра ----
private val Ink = Color(0xFF0C1322)
private val Dusk = Color(0xFF26253F)
private val Amber = Color(0xFFE3B866)
private val Panel = Color(0xFF1A2438)
private val Sand = Color(0xFFEADFC4)
private val Mist = Color(0xFF9AA6BD)

data class AppItem(val label: String, val pkg: String, val icon: Bitmap?, val intent: Intent)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Home() }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent) // кнопка Home возвращает сюда
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { /* лаунчер не закрывается */ }

    // ---------- запуск источников ----------
    private fun openInput(inputId: String) {
        val uri = TvContract.buildChannelUriForPassthroughInput(inputId)
        runCatching {
            startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private fun openTv() {
        val tries = listOf(
            Intent(Intent.ACTION_VIEW, TvContract.Channels.CONTENT_URI),
            Intent(Intent.ACTION_VIEW, TvContract.buildChannelUriForPassthroughInput("com.mediatek.tvinput/.tuner.TunerInputService/HW0")),
            Intent("android.intent.action.VIEW").setComponent(
                ComponentName("com.yandex.tv.live", "com.yandex.tv.live.playback.ChannelPlaybackActivity"))
        )
        for (i in tries) {
            val ok = runCatching { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess
            if (ok) return
        }
    }

    private fun openSettings() {
        runCatching {
            startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private fun loadApps(ctx: Context): List<AppItem> {
        val pm = ctx.packageManager
        var list = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0)
        if (list.size < 3) list = list + pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        return list.distinctBy { it.activityInfo.packageName }
            .filter { it.activityInfo.packageName != ctx.packageName }
            .map {
                val ai = it.activityInfo
                AppItem(
                    it.loadLabel(pm).toString(), ai.packageName,
                    runCatching { it.loadIcon(pm).toBitmap(160, 160) }.getOrNull(),
                    Intent(Intent.ACTION_MAIN).setClassName(ai.packageName, ai.name)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }.sortedBy { it.label.lowercase() }
    }

    // ---------- UI ----------
    @Composable
    fun Home() {
        val apps = remember { loadApps(this) }
        var now by remember { mutableStateOf(Date()) }
        LaunchedEffect(Unit) { while (true) { now = Date(); delay(15_000) } }
        val tvFocus = remember { FocusRequester() }
        LaunchedEffect(Unit) { runCatching { tvFocus.requestFocus() } }

        val hour = Calendar.getInstance().apply { time = now }.get(Calendar.HOUR_OF_DAY)
        val greeting = when (hour) { in 5..11 -> "Доброе утро"; in 12..17 -> "Добрый день"; in 18..22 -> "Добрый вечер"; else -> "Доброй ночи" }

        Column(
            Modifier.fillMaxSize()
                .background(Brush.linearGradient(listOf(Ink, Color(0xFF14213A), Dusk)))
                .padding(horizontal = 64.dp, vertical = 40.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
                Text(SimpleDateFormat("HH:mm", Locale.getDefault()).format(now),
                    color = Sand, fontSize = 84.sp, fontWeight = FontWeight.ExtraLight)
                Spacer(Modifier.width(24.dp))
                Column(Modifier.padding(bottom = 16.dp)) {
                    Text(greeting, color = Sand, fontSize = 24.sp, fontWeight = FontWeight.Medium)
                    Text(SimpleDateFormat("EEEE, d MMMM", Locale("ru")).format(now),
                        color = Mist, fontSize = 18.sp)
                }
            }
            Spacer(Modifier.height(30.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Tile("Телевидение", "Эфир и каналы", Modifier.weight(2f).focusRequester(tvFocus), hero = true) { openTv() }
                Tile("HDMI 1", "Вход", Modifier.weight(1f)) { openInput(HDMI1) }
                Tile("HDMI 2", "Вход", Modifier.weight(1f)) { openInput(HDMI2) }
                Tile("HDMI 3", "Вход", Modifier.weight(1f)) { openInput(HDMI3) }
                Tile("AV", "Вход", Modifier.weight(1f)) { openInput(AV) }
                Tile("Настройки", "Система", Modifier.weight(1f)) { openSettings() }
            }
            Spacer(Modifier.height(36.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Приложения", color = Sand, fontSize = 22.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.width(12.dp))
                Text("${apps.size}", color = Mist, fontSize = 18.sp)
            }
            Spacer(Modifier.height(14.dp))

            LazyVerticalGrid(
                columns = GridCells.Adaptive(160.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                contentPadding = PaddingValues(8.dp)
            ) {
                items(apps, key = { it.pkg }) { a ->
                    AppCard(a) { runCatching { startActivity(a.intent) } }
                }
            }
        }
    }

    @Composable
    fun Tile(title: String, hint: String, modifier: Modifier, hero: Boolean = false, onClick: () -> Unit) {
        var focused by remember { mutableStateOf(false) }
        val scale by animateFloatAsState(if (focused) 1.07f else 1f, tween(160), label = "s")
        val shape = RoundedCornerShape(22.dp)
        val bg = when {
            focused -> Brush.linearGradient(listOf(Sand, Color(0xFFF6EEDA)))
            hero -> Brush.linearGradient(listOf(Color(0xFF3A3350), Color(0xFF2A2740)))
            else -> Brush.linearGradient(listOf(Panel, Color(0xFF151E31)))
        }
        Box(
            modifier.height(124.dp).scale(scale)
                .clip(shape)
                .background(bg)
                .border(if (focused) 2.dp else 1.dp,
                    if (focused) Amber else Color(0x22FFFFFF), shape)
                .onFocusChanged { focused = it.isFocused }
                .clickable(onClick = onClick)
                .padding(20.dp),
            contentAlignment = Alignment.BottomStart
        ) {
            if (hero) Box(Modifier.align(Alignment.TopStart).size(width = 36.dp, height = 4.dp)
                .clip(RoundedCornerShape(2.dp)).background(if (focused) Ink else Amber))
            Column {
                Text(title, color = if (focused) Ink else Sand,
                    fontSize = if (hero) 28.sp else 20.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1)
                Text(hint, color = if (focused) Color(0xFF5B5440) else Mist, fontSize = 14.sp, maxLines = 1)
            }
        }
    }

    @Composable
    fun AppCard(a: AppItem, onClick: () -> Unit) {
        var focused by remember { mutableStateOf(false) }
        val scale by animateFloatAsState(if (focused) 1.1f else 1f, tween(160), label = "a")
        val shape = RoundedCornerShape(20.dp)
        Column(
            Modifier.scale(scale)
                .clip(shape)
                .background(if (focused) Sand else Panel)
                .border(if (focused) 2.dp else 1.dp,
                    if (focused) Amber else Color(0x18FFFFFF), shape)
                .onFocusChanged { focused = it.isFocused }
                .clickable(onClick = onClick)
                .padding(vertical = 18.dp, horizontal = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            a.icon?.let {
                Image(it.asImageBitmap(), null, Modifier.size(72.dp).clip(RoundedCornerShape(16.dp)))
            } ?: Spacer(Modifier.size(72.dp))
            Spacer(Modifier.height(10.dp))
            Text(a.label, color = if (focused) Ink else Sand, fontSize = 16.sp,
                fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}
