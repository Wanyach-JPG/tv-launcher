package com.mylauncher.tv

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.tv.TvContract
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

// ---- ВХОДЫ (взяты из dumpsys tv_input вашего телевизора) ----
private const val HDMI1 = "com.mediatek.tvinput/.hdmi.HDMIInputService/HW4"
private const val HDMI2 = "com.mediatek.tvinput/.hdmi.HDMIInputService/HW5"
private const val HDMI3 = "com.mediatek.tvinput/.hdmi.HDMIInputService/HW6"
private const val AV = "com.mediatek.tvinput/.composite.CompositeInputService/HW1"

// ---- Палитра ----
private val Ink = Color(0xFF0F1626)
private val Panel = Color(0xFF1A2438)
private val Sand = Color(0xFFEADFC4)
private val Mist = Color(0xFF9AA6BD)

data class AppItem(val label: String, val pkg: String, val icon: Bitmap?, val intent: Intent)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Home() }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent) // кнопка Home возвращает сюда
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { /* лаунчер не закрывается */ }

    // ---------- запуск источников ----------
    private fun openInput(inputId: String) {
        val uri = TvContract.buildChannelUriForPassthroughInput(inputId)
        runCatching {
            startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private fun openTv() {
        val tries = listOf(
            Intent(Intent.ACTION_VIEW, TvContract.Channels.CONTENT_URI),
            Intent(Intent.ACTION_VIEW, TvContract.buildChannelUriForPassthroughInput("com.mediatek.tvinput/.tuner.TunerInputService/HW0")),
            Intent("android.intent.action.VIEW").setComponent(
                ComponentName("com.yandex.tv.live", "com.yandex.tv.live.playback.ChannelPlaybackActivity"))
        )
        for (i in tries) {
            val ok = runCatching { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess
            if (ok) return
        }
    }

    private fun openSettings() {
        runCatching {
            startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private fun loadApps(ctx: Context): List<AppItem> {
        val pm = ctx.packageManager
        var list = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0)
        if (list.size < 3) list = list + pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        return list.distinctBy { it.activityInfo.packageName }
            .filter { it.activityInfo.packageName != ctx.packageName }
            .map {
                val ai = it.activityInfo
                AppItem(
                    it.loadLabel(pm).toString(), ai.packageName,
                    runCatching { it.loadIcon(pm).toBitmap(160, 160) }.getOrNull(),
                    Intent(Intent.ACTION_MAIN).setClassName(ai.packageName, ai.name)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }.sortedBy { it.label.lowercase() }
    }

    // ---------- UI ----------
    @Composable
    fun Home() {
        val apps = remember { loadApps(this) }
        var now by remember { mutableStateOf(Date()) }
        LaunchedEffect(Unit) { while (true) { now = Date(); delay(15_000) } }

        Column(Modifier.fillMaxSize().background(Ink).padding(horizontal = 56.dp, vertical = 36.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
                Text(SimpleDateFormat("HH:mm", Locale.getDefault()).format(now),
                    color = Sand, fontSize = 56.sp, fontWeight = FontWeight.Light)
                Spacer(Modifier.width(20.dp))
                Text(SimpleDateFormat("EEEE, d MMMM", Locale("ru")).format(now),
                    color = Mist, fontSize = 20.sp, modifier = Modifier.padding(bottom = 10.dp))
            }
            Spacer(Modifier.height(28.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Tile("Телевидение", Modifier.weight(1.6f), big = true) { openTv() }
                Tile("HDMI 1", Modifier.weight(1f)) { openInput(HDMI1) }
                Tile("HDMI 2", Modifier.weight(1f)) { openInput(HDMI2) }
                Tile("HDMI 3", Modifier.weight(1f)) { openInput(HDMI3) }
                Tile("AV", Modifier.weight(1f)) { openInput(AV) }
                Tile("Настройки", Modifier.weight(1f)) { openSettings() }
            }
            Spacer(Modifier.height(32.dp))
            Text("Приложения", color = Mist, fontSize = 18.sp)
            Spacer(Modifier.height(12.dp))

            LazyVerticalGrid(
                columns = GridCells.Adaptive(150.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(6.dp)
            ) {
                items(apps, key = { it.pkg }) { a ->
                    AppCard(a) { runCatching { startActivity(a.intent) } }
                }
            }
        }
    }

    @Composable
    fun Tile(title: String, modifier: Modifier, big: Boolean = false, onClick: () -> Unit) {
        var focused by remember { mutableStateOf(false) }
        val scale = if (focused) 1.06f else 1f
        Box(
            modifier.height(if (big) 110.dp else 110.dp).scale(scale)
                .clip(RoundedCornerShape(18.dp))
                .background(if (focused) Sand else Panel)
                .onFocusChanged { focused = it.isFocused }
                .clickable(onClick = onClick)
                .padding(18.dp),
            contentAlignment = Alignment.BottomStart
        ) {
            Text(title, color = if (focused) Ink else Sand,
                fontSize = if (big) 24.sp else 19.sp, fontWeight = FontWeight.Medium)
        }
    }

    @Composable
    fun AppCard(a: AppItem, onClick: () -> Unit) {
        var focused by remember { mutableStateOf(false) }
        Column(
            Modifier.scale(if (focused) 1.08f else 1f)
                .clip(RoundedCornerShape(16.dp))
                .background(if (focused) Sand else Panel)
                .onFocusChanged { focused = it.isFocused }
                .clickable(onClick = onClick)
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            a.icon?.let {
                Image(it.asImageBitmap(), null, Modifier.size(64.dp))
            } ?: Spacer(Modifier.size(64.dp))
            Spacer(Modifier.height(8.dp))
            Text(a.label, color = if (focused) Ink else Sand, fontSize = 15.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}
