package com.mylauncher.tv

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.tv.TvContract
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

// ---- Material You: динамические цвета (Android 12+), иначе базовая тональная палитра ----
private val FallbackDark = darkColorScheme(
    primary = Color(0xFFD0BCFF), onPrimary = Color(0xFF381E72),
    primaryContainer = Color(0xFF4F378B), onPrimaryContainer = Color(0xFFEADDFF),
    secondary = Color(0xFFCCC2DC), onSecondary = Color(0xFF332D41),
    secondaryContainer = Color(0xFF4A4458), onSecondaryContainer = Color(0xFFE8DEF8),
    tertiary = Color(0xFFEFB8C8), onTertiary = Color(0xFF492532),
    tertiaryContainer = Color(0xFF633B48), onTertiaryContainer = Color(0xFFFFD8E4),
    background = Color(0xFF141218), onBackground = Color(0xFFE6E0E9),
    surface = Color(0xFF141218), onSurface = Color(0xFFE6E0E9),
    surfaceVariant = Color(0xFF49454F), onSurfaceVariant = Color(0xFFCAC4D0),
    surfaceContainer = Color(0xFF211F26), surfaceContainerHigh = Color(0xFF2B2930),
    surfaceContainerHighest = Color(0xFF36343B), outline = Color(0xFF938F99)
)

data class AppItem(val label: String, val pkg: String, val icon: Bitmap?, val intent: Intent)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Home() }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent) // кнопка Home возвращает сюда
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { /* лаунчер не закрывается */ }

    // ---------- запуск ----------
    private fun openTv() {
        val tries = listOf(
            Intent(Intent.ACTION_VIEW, TvContract.Channels.CONTENT_URI),
            Intent(Intent.ACTION_VIEW, TvContract.buildChannelUriForPassthroughInput("com.mediatek.tvinput/.tuner.TunerInputService/HW0")),
            Intent("android.intent.action.VIEW").setComponent(
                ComponentName("com.yandex.tv.live", "com.yandex.tv.live.playback.ChannelPlaybackActivity"))
        )
        for (i in tries) {
            val ok = runCatching { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess
            if (ok) return
        }
    }

    private fun openSettings() {
        runCatching {
            startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private fun loadApps(ctx: Context): List<AppItem> {
        val pm = ctx.packageManager
        var list = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0)
        if (list.size < 3) list = list + pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        return list.distinctBy { it.activityInfo.packageName }
            .filter { it.activityInfo.packageName != ctx.packageName }
            .map {
                val ai = it.activityInfo
                AppItem(
                    it.loadLabel(pm).toString(), ai.packageName,
                    runCatching { it.loadIcon(pm).toBitmap(160, 160) }.getOrNull(),
                    Intent(Intent.ACTION_MAIN).setClassName(ai.packageName, ai.name)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }.sortedBy { it.label.lowercase() }
    }

    // ---------- UI ----------
    @Composable
    fun Home() {
        val ctx = LocalContext.current
        val scheme = if (Build.VERSION.SDK_INT >= 31) dynamicDarkColorScheme(ctx) else FallbackDark
        MaterialTheme(colorScheme = scheme) { HomeContent() }
    }

    @Composable
    fun HomeContent() {
        val cs = MaterialTheme.colorScheme
        val apps = remember { loadApps(this) }
        var now by remember { mutableStateOf(Date()) }
        LaunchedEffect(Unit) { while (true) { now = Date(); delay(15_000) } }
        val tvFocus = remember { FocusRequester() }
        LaunchedEffect(Unit) { runCatching { tvFocus.requestFocus() } }

        Column(Modifier.fillMaxSize().background(cs.surface)
            .padding(horizontal = 64.dp, vertical = 40.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(SimpleDateFormat("HH:mm", Locale.getDefault()).format(now),
                    color = cs.onSurface, fontSize = 80.sp, fontWeight = FontWeight.Normal)
                Spacer(Modifier.width(24.dp))
                Box(Modifier.clip(CircleShape).background(cs.secondaryContainer)
                    .padding(horizontal = 22.dp, vertical = 10.dp)) {
                    Text(SimpleDateFormat("EEEE, d MMMM", Locale("ru")).format(now)
                        .replaceFirstChar { it.uppercase() },
                        color = cs.onSecondaryContainer, fontSize = 18.sp, fontWeight = FontWeight.Medium)
                }
            }
            Spacer(Modifier.height(28.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Tile("Телевидение", Modifier.weight(2f).focusRequester(tvFocus), TileKind.Hero,
                    { c -> Icon(Icons.Rounded.PlayArrow, null, tint = c, modifier = Modifier.size(28.dp)) }) { openTv() }
                Tile("Настройки", Modifier.weight(1f), TileKind.Accent,
                    { c -> Icon(Icons.Rounded.Settings, null, tint = c, modifier = Modifier.size(26.dp)) }) { openSettings() }
            }
            Spacer(Modifier.height(32.dp))
            Text("Приложения", color = cs.onSurfaceVariant, fontSize = 20.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(14.dp))

            LazyVerticalGrid(
                columns = GridCells.Adaptive(150.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(8.dp)
            ) {
                items(apps, key = { it.pkg }) { a ->
                    AppCard(a) { runCatching { startActivity(a.intent) } }
                }
            }
        }
    }

    enum class TileKind { Hero, Tonal, Accent }

    @Composable
    fun Digit(text: String, color: Color) {
        Text(text, color = color, fontSize = if (text.length > 1) 16.sp else 22.sp, fontWeight = FontWeight.Bold)
    }

    @Composable
    fun Tile(title: String, modifier: Modifier, kind: TileKind,
             icon: @Composable (Color) -> Unit, onClick: () -> Unit) {
        val cs = MaterialTheme.colorScheme
        var focused by remember { mutableStateOf(false) }
        val scale by animateFloatAsState(if (focused) 1.06f else 1f, tween(180), label = "s")
        val rest = when (kind) {
            TileKind.Hero -> cs.primaryContainer
            TileKind.Tonal -> cs.secondaryContainer
            TileKind.Accent -> cs.tertiaryContainer
        }
        val onRest = when (kind) {
            TileKind.Hero -> cs.onPrimaryContainer
            TileKind.Tonal -> cs.onSecondaryContainer
            TileKind.Accent -> cs.onTertiaryContainer
        }
        val bg by animateColorAsState(if (focused) cs.primary else rest, tween(180), label = "b")
        val fg = if (focused) cs.onPrimary else onRest
        val shape = RoundedCornerShape(28.dp)
        Column(
            modifier.height(128.dp).scale(scale).clip(shape).background(bg)
                .border(if (focused) 3.dp else 0.dp, cs.onSurface.copy(alpha = if (focused) 0.9f else 0f), shape)
                .onFocusChanged { focused = it.isFocused }
                .clickable(onClick = onClick)
                .padding(18.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Box(Modifier.size(46.dp).clip(CircleShape)
                .background(fg.copy(alpha = 0.14f)), contentAlignment = Alignment.Center) { icon(fg) }
            Text(title, color = fg, fontSize = if (kind == TileKind.Hero) 24.sp else 19.sp,
                fontWeight = FontWeight.Medium, maxLines = 1)
        }
    }

    @Composable
    fun AppCard(a: AppItem, onClick: () -> Unit) {
        val cs = MaterialTheme.colorScheme
        var focused by remember { mutableStateOf(false) }
        val scale by animateFloatAsState(if (focused) 1.08f else 1f, tween(180), label = "a")
        val bg by animateColorAsState(if (focused) cs.primaryContainer else cs.surfaceContainer, tween(180), label = "c")
        val shape = RoundedCornerShape(28.dp)
        Column(
            Modifier.scale(scale).clip(shape).background(bg)
                .border(if (focused) 3.dp else 0.dp, if (focused) cs.primary else Color.Transparent, shape)
                .onFocusChanged { focused = it.isFocused }
                .clickable(onClick = onClick)
                .padding(vertical = 18.dp, horizontal = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(Modifier.size(84.dp).clip(RoundedCornerShape(24.dp)).background(cs.surfaceContainerHighest),
                contentAlignment = Alignment.Center) {
                a.icon?.let { Image(it.asImageBitmap(), null, Modifier.size(60.dp)) }
            }
            Spacer(Modifier.height(10.dp))
            Text(a.label, color = if (focused) cs.onPrimaryContainer else cs.onSurface, fontSize = 16.sp,
                fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}
